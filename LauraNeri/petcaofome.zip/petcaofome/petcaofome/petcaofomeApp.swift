//
//  petcaofomeApp.swift
//  petcaofome
//
//  Created by Student13 on 24/03/23.
//

import SwiftUI

@main
struct petcaofomeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
